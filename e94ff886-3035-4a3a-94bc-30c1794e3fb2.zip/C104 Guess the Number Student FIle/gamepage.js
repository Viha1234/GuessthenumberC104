// generation of random value

// count of attempts
// until hit
  
// function for the number sent by the user